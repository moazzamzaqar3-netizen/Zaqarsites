import { MessageCircle, Sparkles } from 'lucide-react';
import { CONTACT_INFO } from '../data/content';

export function FloatingWhatsApp() {
  return (
    <aside aria-label="WhatsApp quick chat" className="fixed bottom-6 right-6 z-50 flex items-center gap-3">
      {/* Tooltip Pill */}
      <div className="hidden sm:flex items-center gap-2 bg-slate-900/90 backdrop-blur-md text-white text-xs font-bold py-2 px-3.5 rounded-2xl shadow-xl border border-slate-700/80 animate-in fade-in slide-in-from-right-4 duration-300">
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
        </span>
        <span className="flex items-center gap-1">
          <span>Chat with</span>
          <span className="text-emerald-400 font-extrabold">Moazzam Zaqar</span>
        </span>
      </div>

      {/* Floating Button with Smooth Hover Scale & Shadow Depth */}
      <div className="animate-subtle-bounce">
        <a
          href={`${CONTACT_INFO.whatsappUrl}?text=${encodeURIComponent('Hi Moazzam, I am interested in building a website for my business.')}`}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Direct WhatsApp Chat with Moazzam Zaqar"
          className="group relative w-14 h-14 bg-emerald-500 hover:bg-emerald-600 text-white rounded-full flex items-center justify-center shadow-xl shadow-emerald-600/35 cursor-pointer outline-none focus:ring-4 focus:ring-emerald-400/40"
          id="floating-whatsapp-btn"
        >
          {/* Subtle pulse ring */}
          <span className="absolute -inset-1 rounded-full bg-emerald-500/30 blur-xs group-hover:bg-emerald-400/40 transition-colors pointer-events-none" />

          {/* WhatsApp Icon */}
          <MessageCircle className="w-7 h-7 fill-current relative z-10 transition-transform duration-300 group-hover:scale-105" />

          {/* Quick sparkles indicator */}
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-amber-400 text-slate-900 rounded-full flex items-center justify-center text-[10px] font-black shadow-md border-2 border-white pointer-events-none">
            <Sparkles className="w-2.5 h-2.5" />
          </span>
        </a>
      </div>
    </aside>
  );
}